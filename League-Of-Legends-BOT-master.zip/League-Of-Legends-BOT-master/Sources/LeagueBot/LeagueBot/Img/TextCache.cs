﻿using LeagueBot.IO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LeagueBot.Img
{
    public class TextCache
    {
    
        public const int STEP = 250;

        private static Dictionary<string, int> TextCoords = new Dictionary<string, int>();
        

      
        
    }
}
